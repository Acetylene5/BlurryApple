# -*- coding: utf-8 -*-
"""
Created on Thu Jun 19 06:24:06 2014

@author: fvidal
"""

try:
    import pyfits
except:
    from astropy.io import fits as pyfits
    
import numpy as np

def readfits(filename):
    print "ici"
    header = pyfits.getheader(filename)
    print header
    if(header['NAXIS'] >0): # No extension in fits file => easy case
        data = pyfits.getdata(str(filename))
    else: #if extensions
        nbHDU = header['NEXTEND'] # Get nb HDU in header
        data = []
        for i in range(nbHDU):#read each hdu
            try:
                image = pyfits.getdata(str(filename),i+1)
            except IOError:
                print "Erreur while opening file!"
            dimim = image.shape
            if(len(dimim)==3):
                image= np.reshape(image,[list(dimim)[0],list(dimim)[1]*list(dimim)[2]])
            if(i!=0):
                if(len(image.shape)>1):#if >1D
                    if(list(np.array(data).shape)[0] == list(np.array(image).shape)[0]):# common dimension is X
                        data = np.concatenate((data,image), axis=1) # concatenate arrays on Y axis
                    elif(list(np.array(data.shape))[1] == list(np.array(image).shape)[1]):# common dimension is Y
                        data = np.concatenate((data,image), axis=0) # concatenate arrays on X axis
                    else:
                        print 'Error: Cannot concatenate data from HDU. Arrays must have 1 dimension in common.'
                        print 'Arrays must have 1 dimension in common.'
                        return
                else: #1D data
                    data = np.concatenate((data,image))
            else:
                data = image
    return np.array(data)
    
    
