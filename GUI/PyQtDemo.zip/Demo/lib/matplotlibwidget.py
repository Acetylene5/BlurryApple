# -*- coding: utf-8 -*-
"""
Created on Tue Jun 24 00:27:01 2014

@author: fvidal
"""
"""
This file is used to create an embeddable matplotlib figure/canvas in the Qt GUI.
"""

       
#!/usr/bin/python
import sys
import platform
from PyQt4 import QtCore, QtGui
from PyQt4.QtCore import *
from PyQt4.QtGui import *
 
from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas 
from matplotlib.backends.backend_qt4agg import NavigationToolbar2QTAgg as Navigationtoolbar
from matplotlib.figure import Figure
 
import matplotlib
#matplotlib.use('Qt4Agg')
#matplotlib.rcParams['backend.qt4']='PySide'
 
#Embeddable matplotlib figure/canvas
class MplCanvas(FigureCanvas): 
    def __init__(self):
        self.fig = Figure()
        self.axes = self.fig.add_subplot(111)
 
        FigureCanvas.__init__(self, self.fig)
        FigureCanvas.setSizePolicy(self, QtGui.QSizePolicy.Expanding,QtGui.QSizePolicy.Expanding)
        FigureCanvas.updateGeometry(self)
 
#creates embeddable matplotlib figure/canvas with toolbar
class MatplotlibWidget(QtGui.QWidget):
 
    def __init__(self, parent = None):
        QtGui.QWidget.__init__(self, parent)
        self.create_framentoolbar()
 
    def create_framentoolbar(self):
        self.frame = QWidget()
        self.canvas = MplCanvas()
        self.canvas.setParent(self.frame)
        self.mpltoolbar = Navigationtoolbar(self.canvas, self.frame)
        self.vbl = QtGui.QVBoxLayout()
        self.vbl.addWidget(self.canvas)
        self.vbl.addWidget(self.mpltoolbar)
        self.setLayout(self.vbl)        
        
